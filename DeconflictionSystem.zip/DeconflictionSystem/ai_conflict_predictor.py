import json
import numpy as np
from sklearn.ensemble import RandomForestClassifier

def extract_features(mission):
    return [len(mission["waypoints"]), mission["times"][-1] - mission["times"][0]]

def train_ai_model(filepath):
    with open(filepath) as f:
        data = json.load(f)
    X = [extract_features(d) for d in data]
    y = [d.get("label", 0) for d in data]
    model = RandomForestClassifier()
    model.fit(X, y)
    return model

def predict_conflict_ai(model, mission):
    return model.predict([extract_features(mission)])[0]