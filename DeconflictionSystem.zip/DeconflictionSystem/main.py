from conflict_checker import check_conflicts
from ai_conflict_predictor import train_ai_model, predict_conflict_ai
from simulator import load_primary_mission, load_other_drones
from visualizer import visualize_conflicts
import json

if __name__ == "__main__":
    primary = load_primary_mission("data/primary_mission.json")
    others = load_other_drones("data/other_flights.json")

    result = check_conflicts(primary, others)
    print(result["status"])
    if result["status"] == "conflict detected":
        for detail in result["conflicts"]:
            print(detail)

    visualize_conflicts(primary, others, result)

    model = train_ai_model("data/other_flights.json")
    prediction = predict_conflict_ai(model, primary)
    print("AI prediction:", "Conflict likely" if prediction else "Clear")