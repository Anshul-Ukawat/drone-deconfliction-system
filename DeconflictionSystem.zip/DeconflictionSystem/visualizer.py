import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def visualize_conflicts(primary, others, result):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    px = [wp['x'] for wp in primary['waypoints']]
    py = [wp['y'] for wp in primary['waypoints']]
    pz = [wp.get('z', 0) for wp in primary['waypoints']]
    ax.plot(px, py, pz, label='Primary Drone', color='blue')

    for drone in others:
        dx = [wp['x'] for wp in drone['waypoints']]
        dy = [wp['y'] for wp in drone['waypoints']]
        dz = [wp.get('z', 0) for wp in drone['waypoints']]
        ax.plot(dx, dy, dz, label=f'Drone {drone["id"]}', linestyle='--')

    if result["status"] == "conflict detected":
        for conflict in result["conflicts"]:
            ax.scatter(*conflict["location"], color='red', s=50, label='Conflict Point')

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.legend()
    plt.show()