import json

def load_primary_mission(filepath):
    with open(filepath) as f:
        return json.load(f)

def load_other_drones(filepath):
    with open(filepath) as f:
        return json.load(f)