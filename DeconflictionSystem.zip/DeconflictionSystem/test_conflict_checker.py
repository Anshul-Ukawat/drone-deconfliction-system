from conflict_checker import check_conflicts

def test_no_conflict():
    primary = {"waypoints": [{"x": 0, "y": 0, "z": 0}], "times": [0]}
    others = [{"id": "A", "waypoints": [{"x": 100, "y": 100, "z": 0}], "times": [0]}]
    result = check_conflicts(primary, others)
    assert result["status"] == "clear"

def test_conflict_detected():
    primary = {"waypoints": [{"x": 0, "y": 0, "z": 0}], "times": [5]}
    others = [{"id": "B", "waypoints": [{"x": 1, "y": 1, "z": 0}], "times": [5]}]
    result = check_conflicts(primary, others)
    assert result["status"] == "conflict detected"

if __name__ == "__main__":
    test_no_conflict()
    test_conflict_detected()
    print("All tests passed.")