import math

def euclidean_distance(a, b):
    return math.sqrt((a['x'] - b['x'])**2 + (a['y'] - b['y'])**2 + (a.get('z', 0) - b.get('z', 0))**2)

def check_conflicts(primary, others, threshold=5.0):
    conflicts = []
    for i, p_wp in enumerate(primary["waypoints"]):
        for drone in others:
            for j, o_wp in enumerate(drone["waypoints"]):
                spatial_dist = euclidean_distance(p_wp, o_wp)
                time_diff = abs(primary["times"][i] - drone["times"][j])
                if spatial_dist < threshold and time_diff == 0:
                    conflicts.append({
                        "location": (p_wp["x"], p_wp["y"], p_wp.get("z", 0)),
                        "time": primary["times"][i],
                        "conflict_with": drone["id"]
                    })
    return {
        "status": "conflict detected" if conflicts else "clear",
        "conflicts": conflicts
    }